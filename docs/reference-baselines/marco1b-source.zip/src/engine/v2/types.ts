export type Action =
  | "esperar"
  | "treinar"
  | "observar"
  | "confrontar"
  | "comunicar"
  | "perdoar"
  | "buscar_acordo"
  | "conviver"
  | "proteger";
export const outcomes = [
  "vingança cumprida",
  "desistência",
  "alvo morto por outra causa",
  "reconciliação",
  "fuga",
  "objetivo frustrado",
] as const;
export type Outcome = (typeof outcomes)[number];
export interface Person {
  id: string;
  kind: "person";
  name: string;
  born: number;
  alive: boolean;
  death?: string;
  killer?: string;
  traits: {
    rancor: number;
    coragem: number;
    disciplina: number;
    cautela: number;
  };
  values: {
    familia: number;
    vinganca: number;
    paz: number;
    amizade?: number;
    solidariedade?: number;
  };
  skill: number;
  kin: string[];
  rival?: string;
  hostility: number;
  trainAccess: boolean;
  canHelp: boolean;
  helpFrom?: string;
  helpedBy?: string;
  present: boolean;
  escaped: boolean;
  remorse: number;
  informed: string[];
  goal?: string;
  memory?: string;
  acquaintances?: Record<string, string>;
  bonds?: Record<
    string,
    { trust: number; interactions: number; source: string }
  >;
  personalGoals?: string[];
  lastBy: Record<string, string>;
}
export interface Memory {
  id: string;
  kind: "memory";
  owner: string;
  victim: string;
  offender: string;
  source: string;
  at: number;
  weight: number;
  offenderSkillEstimate: number;
  rancor: number;
}
export interface Goal {
  id: string;
  kind: "goal";
  owner: string;
  target: string;
  victim: string;
  offense: string;
  memory: string;
  adopted: number;
  closed?: number;
  outcome?: Outcome;
  source: string;
  accordIntent?: string;
  accordRejected?: string;
}
export interface PersonalGoal {
  id: string;
  kind: "personalGoal";
  type: "proteger" | "amizade";
  owner: string;
  target: string;
  source: string;
  lastEvent: string;
  adopted: number;
  closed?: number;
  status?: "completed" | "failed" | "abandoned";
  reason?: string;
  threat?: string;
  perception?: string;
  aggressor?: string;
  threatResolved?: boolean;
  interventions: number;
  rejections: number;
}
export interface Place {
  id: string;
  kind: "place";
  name: string;
}
export type Entity = Person | Memory | Goal | PersonalGoal | Place;
export interface Candidate {
  action: Action;
  score: number;
  base: number;
  noise: number;
  factors: Record<string, number>;
  evidence: string[];
  target?: string;
}
export interface Decision {
  actor: string;
  chosen: Action;
  target?: string;
  reason: string;
  candidates: Candidate[];
}
export type Effect =
  { op: "create"; entity: Entity } | { op: "replace"; entity: Entity };
export interface SliceEvent {
  readonly id: string;
  readonly seq: number;
  readonly ano: number;
  readonly dia: number;
  readonly month: number;
  readonly type: string;
  readonly participants: readonly {
    id: string;
    role:
      "actor" | "target" | "victim" | "witness" | "reference" | "beneficiary";
  }[];
  readonly location: string;
  readonly causes: readonly string[];
  readonly effects: readonly Effect[];
  readonly data: Readonly<Record<string, unknown>>;
  readonly decision?: Decision;
}
export interface Schedule {
  id: string;
  from: number;
  until: number;
  period: number;
  absentMonths: number;
}
export interface Scenario {
  seed: string;
  mode: "free" | "fixture";
  months: number;
  people: Person[];
  schedules: Schedule[];
  focal: string;
  victim: string;
  offender: string;
  helper: string;
  blockedInformation: string[];
  noReencounter: boolean;
  externalDeathMonth?: number;
  personalObjectives?: boolean;
  friendTargets?: Record<string, string>;
  blockedThreatPerception?: string[];
}
export interface SliceWorld {
  version: 2;
  engine: "revenge-slice-1" | "agents-slice-1a" | "agents-slice-1b";
  scenario: Scenario;
  events: SliceEvent[];
  entities: Record<string, Entity>;
  nextMonth: number;
  complete: boolean;
}
export interface Reaction {
  kind: "perceive" | "hear" | "help" | "settleDeath" | "threat";
  source: string;
  recipient: string;
  sender?: string;
}
