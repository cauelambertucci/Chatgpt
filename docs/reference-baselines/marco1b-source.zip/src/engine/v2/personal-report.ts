import type { SliceWorld, PersonalGoal } from "./types";
import { getPerson } from "./engine";
import { collapsedCausality } from "./causal";
import { causalAncestors } from "./report";
export interface PersonalStory {
  seed: string;
  goal: string;
  type: PersonalGoal["type"];
  status: string;
  owner: string;
  target: string;
  depth: number;
  rawEvents: string[];
  chain: string[];
  periodsCollapsed: number;
  narrative: string[];
}
const date = (m: number) => `ano ${Math.floor(m / 12)}, mês ${(m % 12) + 1}`;
export const personalGoals = (w: SliceWorld) =>
  Object.values(w.entities).filter(
    (x): x is PersonalGoal => x.kind === "personalGoal",
  );
export function personalStory(w: SliceWorld, g: PersonalGoal): PersonalStory {
  const owner = getPerson(w, g.owner),
    target = getPerson(w, g.target),
    end =
      w.events.find(
        (e) => e.type === "personalGoal.closed" && e.data.goal === g.id,
      )?.id || g.lastEvent,
    graph = collapsedCausality(w, end);
  const narrative = [
    `${owner.name} assumiu o objetivo de ${g.type === "amizade" ? "construir amizade com" : "proteger"} ${target.name} no ${date(g.adopted)}.`,
  ];
  if (g.type === "amizade") {
    const replies = w.events.filter(
      (e) => e.type === "social.responded" && e.data.goal === g.id,
    );
    narrative.push(
      `Foram ${replies.filter((e) => e.data.accepted).length} convites aceitos e ${replies.filter((e) => !e.data.accepted).length} recusados; amizade só foi reconhecida após confiança recíproca.`,
    );
  } else {
    const adoption = w.events[Number(g.source.split(":")[1])],
      seen = adoption.causes
        .map((id) => w.events[Number(id.split(":")[1])])
        .find((e) => e.type === "threat.perceived"),
      threat = seen
        ? w.events[Number(String(seen.data.threat).split(":")[1])]
        : undefined;
    if (threat)
      narrative.push(
        `O compromisso nasceu de uma ameaça de ${getPerson(w, String(threat.data.aggressor)).name} que ${owner.name} presenciou, sem notícia global automática.`,
      );
    narrative.push(
      `Intervenções bem-sucedidas: ${g.interventions}. ${target.name} terminou o horizonte ${target.alive ? "vivo" : "morto"}.`,
    );
  }
  narrative.push(
    `Desfecho no ${date(g.closed ?? w.nextMonth - 1)}: ${g.status || "em andamento"}. ${g.reason || ""}`,
  );
  return {
    seed: w.scenario.seed,
    goal: g.id,
    type: g.type,
    status: g.status || "active",
    owner: owner.name,
    target: target.name,
    depth: graph.depth,
    rawEvents: causalAncestors(w, end),
    chain: graph.chain,
    periodsCollapsed: graph.episodes.reduce(
      (n, e) => n + Math.max(0, e.periods - 1),
      0,
    ),
    narrative,
  };
}
export function personalStories(w: SliceWorld, limit = 10): PersonalStory[] {
  return personalGoals(w)
    .sort(
      (a, b) =>
        Number(b.status === "completed") - Number(a.status === "completed") ||
        Number(b.type === "proteger") - Number(a.type === "proteger") ||
        (a.id < b.id ? -1 : a.id > b.id ? 1 : 0),
    )
    .slice(0, limit)
    .map((g) => personalStory(w, g));
}
