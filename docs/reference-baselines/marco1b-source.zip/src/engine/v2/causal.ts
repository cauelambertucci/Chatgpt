import type { SliceWorld } from "./types";
export interface CausalEpisode {
  id: string;
  type: string;
  actor?: string;
  action?: string;
  from: number;
  to: number;
  periods: number;
  gain: number;
  members: string[];
  causes: string[];
}
/** Read-only quotient DAG. Repeated periods are grouped before any depth is computed. */
export function collapsedCausality(w: SliceWorld, end: string) {
  const map = new Map<string, string>(),
    nodes = new Map<string, CausalEpisode>(),
    last = new Map<string, CausalEpisode>();
  for (const e of w.events) {
    const actor = e.decision?.actor,
      action = String(e.data.action || "");
    let group: CausalEpisode | undefined;
    if (e.type === "activity.period" && actor) {
      const prev = last.get(actor);
      if (prev && prev.action === action && prev.to + 1 === e.month)
        group = prev;
      if (!group) {
        group = {
          id: e.id,
          type: "activity.period",
          actor,
          action,
          from: e.month,
          to: e.month,
          periods: 0,
          gain: 0,
          members: [],
          causes: [],
        };
        nodes.set(group.id, group);
        last.set(actor, group);
      }
    } else {
      for (const p of e.participants)
        if (p.role !== "reference") last.delete(p.id);
    }
    if (!group) {
      group = {
        id: e.id,
        type: e.type,
        actor,
        from: e.month,
        to: e.month,
        periods: 0,
        gain: 0,
        members: [],
        causes: [],
      };
      nodes.set(group.id, group);
    }
    group.to = e.month;
    group.periods += e.type === "activity.period" ? 1 : 0;
    group.gain += Number(e.data.gain || 0);
    group.members.push(e.id);
    map.set(e.id, group.id);
  }
  for (const e of w.events) {
    const node = nodes.get(map.get(e.id)!)!;
    for (const cause of e.causes) {
      const id = map.get(cause);
      if (!id) throw Error(`Missing cause ${cause}`);
      if (id !== node.id && !node.causes.includes(id)) node.causes.push(id);
    }
  }
  const endNode = map.get(end);
  if (!endNode) throw Error(`Missing end ${end}`);
  const needed = new Set<string>(),
    pending = [endNode];
  while (pending.length) {
    const id = pending.pop()!;
    if (needed.has(id)) continue;
    needed.add(id);
    pending.push(...nodes.get(id)!.causes);
  }
  const indegree = new Map<string, number>(),
    children = new Map<string, string[]>();
  for (const id of needed) {
    const n = nodes.get(id)!;
    indegree.set(id, n.causes.length);
    for (const c of n.causes) children.set(c, [...(children.get(c) || []), id]);
  }
  const ready = [...needed].filter((id) => indegree.get(id) === 0).sort(),
    depth = new Map<string, number>(),
    parent = new Map<string, string>();
  let visited = 0;
  while (ready.length) {
    const id = ready.shift()!,
      node = nodes.get(id)!;
    visited++;
    let best = 0,
      prev: string | undefined;
    for (const c of node.causes) {
      const d = depth.get(c)!;
      if (d > best) {
        best = d;
        prev = c;
      }
    }
    depth.set(id, best + 1);
    if (prev) parent.set(id, prev);
    for (const next of children.get(id) || []) {
      indegree.set(next, indegree.get(next)! - 1);
      if (indegree.get(next) === 0) {
        ready.push(next);
        ready.sort();
      }
    }
  }
  if (visited !== needed.size)
    throw Error("Collapsing periods produced a causal cycle");
  const chain: string[] = [];
  let id: string | undefined = endNode;
  while (id) {
    chain.push(id);
    id = parent.get(id);
  }
  return {
    depth: depth.get(endNode)!,
    chain: chain.reverse(),
    episodes: [...needed]
      .map((id) => nodes.get(id)!)
      .sort(
        (a, b) =>
          a.from - b.from ||
          Number(a.id.split(":")[1]) - Number(b.id.split(":")[1]),
      ),
  };
}
