import type { Entity, Person, SliceWorld, PersonalGoal } from "./types";
import { applyEvent, goals } from "./engine";
import { outcomes } from "./types";
export function validateSlice(w: SliceWorld): string[] {
  const errors: string[] = [];
  const fail = (m: string) => errors.push(m);
  const state: Record<string, Entity> = {},
    ids = new Set<string>();
  const refs = (id: string, at: string) => {
    if (!state[id]) fail(`${at}: referência inexistente ${id}`);
  };
  try {
    if (
      w.version !== 2 ||
      !["revenge-slice-1", "agents-slice-1a", "agents-slice-1b"].includes(
        w.engine,
      )
    )
      fail("Versão inválida");
    let month = -1;
    for (let i = 0; i < w.events.length; i++) {
      const e = w.events[i];
      if (e.id !== `event:${i}` || e.seq !== i || ids.has(e.id))
        fail(`${e.id}: ordem/ID inválido`);
      if (
        e.month < month ||
        e.month < 0 ||
        e.month >= w.scenario.months ||
        e.ano !== Math.floor(e.month / 12) ||
        e.dia !== (e.month % 12) * 30
      )
        fail(`${e.id}: tempo inválido`);
      month = e.month;
      if (
        !Array.isArray(e.causes) ||
        (i !== 0 && e.causes.length === 0) ||
        (i === 0 && (e.type !== "world.created" || e.causes.length !== 0))
      )
        fail(`${e.id}: causas ausentes`);
      for (const cause of e.causes || [])
        if (!ids.has(cause)) fail(`${e.id}: causa futura/inexistente ${cause}`);
      for (const effect of e.effects)
        if (effect.op === "create" && state[effect.entity.id])
          fail(`${e.id}: entidade duplicada`);
      const created = new Set(
        e.effects.filter((f) => f.op === "create").map((f) => f.entity.id),
      );
      for (const p of e.participants) {
        if (!state[p.id] && !created.has(p.id))
          fail(`${e.id}: participante inexistente ${p.id}`);
        const person = state[p.id];
        if (
          person?.kind === "person" &&
          ["actor", "target", "witness"].includes(p.role) &&
          !person.alive
        )
          fail(`${e.id}: morto agiu ${p.id}`);
        if (person?.kind === "person" && person.born > e.ano)
          fail(`${e.id}: pessoa antes de nascer`);
      }
      if (!state[e.location] && !created.has(e.location))
        fail(`${e.id}: local inválido`);
      if (e.decision) {
        const p = state[e.decision.actor];
        if (p?.kind !== "person" || !p.alive || !p.present)
          fail(`${e.id}: decisão inelegível`);
        const best = e.decision.candidates[0];
        if (!best || best.action !== e.decision.chosen)
          fail(`${e.id}: utilidade não venceu`);
        for (const c of e.decision.candidates) {
          if (
            c.score !== c.base + c.noise ||
            Math.abs(c.noise) > 25 ||
            c.base !== Object.values(c.factors).reduce((a, b) => a + b, 0)
          )
            fail(`${e.id}: escore inválido`);
          if (c.score > best.score) fail(`${e.id}: ação inferior escolhida`);
          for (const evidence of c.evidence)
            if (!ids.has(evidence)) fail(`${e.id}: evidência futura`);
        }
        if (
          e.decision.chosen === "treinar" &&
          p?.kind === "person" &&
          !p.trainAccess
        )
          fail(`${e.id}: treino sem acesso`);
      }
      if (e.type === "person.died") {
        const p = state[String(e.data.victim)];
        if (p?.kind !== "person" || !p.alive)
          fail(`${e.id}: morte duplicada/inválida`);
        if (
          !e.causes.some((id) =>
            ["confrontation.resolved", "external.incident"].includes(
              w.events[Number(id.split(":")[1])]?.type,
            ),
          )
        )
          fail(`${e.id}: morte sem resolução`);
      }
      if (e.type === "information.received") {
        const offense = w.events[Number(String(e.data.offense).split(":")[1])];
        if (offense?.type !== "person.died" || offense.seq >= e.seq)
          fail(`${e.id}: informação inválida`);
        const origin = w.events[Number(String(e.data.source).split(":")[1])];
        if (!origin || !e.causes.includes(origin.id))
          fail(`${e.id}: notícia sem fonte`);
        if (origin && origin.id !== offense?.id) {
          const sender = state[String(origin.data.sender)];
          if (
            origin.type !== "information.shared" ||
            origin.data.offense !== offense?.id ||
            sender?.kind !== "person" ||
            !sender.informed.includes(String(e.data.offense))
          )
            fail(`${e.id}: informação sem canal conhecido`);
        }
      }
      if (e.type === "activity.period") {
        if (e.data.periodMonths !== 1) fail(`${e.id}: rotina não mensal`);
        if (
          Number(e.data.skillAfter) !==
          Number(e.data.skillBefore) + Number(e.data.gain)
        )
          fail(`${e.id}: ganho incoerente`);
      }
      if (
        [
          "person.met",
          "social.invited",
          "social.responded",
          "relationship.strengthened",
          "friendship.formed",
          "agreement.offered",
          "agreement.responded",
          "reconciliation.agreed",
          "threat.announced",
          "threat.perceived",
          "protection.intervened",
          "protection.failed",
        ].includes(e.type)
      )
        for (const p of e.participants) {
          const person = state[p.id];
          if (
            person?.kind === "person" &&
            p.role !== "reference" &&
            (!person.alive || !person.present)
          )
            fail(`${e.id}: interação sem presença`);
        }
      if (e.type === "friendship.formed") {
        const a = state[String(e.data.first)] as Person,
          b = state[String(e.data.second)] as Person;
        if (
          (a?.bonds?.[b?.id]?.trust || 0) < 60 ||
          (b?.bonds?.[a?.id]?.trust || 0) < 60
        )
          fail(`${e.id}: amizade unilateral`);
      }
      if (e.type === "reconciliation.agreed" && e.data.accepted !== true)
        fail(`${e.id}: reconciliação unilateral`);
      for (const effect of e.effects) {
        const before = state[effect.entity.id],
          after = effect.entity;
        if (
          effect.op === "replace" &&
          before?.kind === "person" &&
          after.kind === "person"
        ) {
          for (const key of Object.keys(after) as (keyof Person)[]) {
            if (key === "lastBy") continue;
            if (
              JSON.stringify(before[key]) !== JSON.stringify(after[key]) &&
              after.lastBy[key] !== e.id
            )
              fail(`${e.id}: mudança sem procedência do campo ${key}`);
          }
          if (before.alive !== after.alive && e.type !== "person.died")
            fail(`${e.id}: morte fora do evento de morte`);
          if (before.skill !== after.skill && e.type !== "activity.period")
            fail(`${e.id}: habilidade fora de prática`);
        }
      }
      applyEvent(state, e);
      ids.add(e.id);
      for (const effect of e.effects) {
        const x = effect.entity;
        for (const k of Object.keys(x))
          if (
            !Number.isFinite(
              typeof (x as unknown as Record<string, unknown>)[k] === "number"
                ? (x as unknown as Record<string, number>)[k]
                : 0,
            )
          )
            fail(`${e.id}: número inválido`);
        if (x.kind === "person") {
          if (x.skill < 0 || x.skill > 1000)
            fail(`${e.id}: habilidade inválida`);
          for (const n of Object.values(x.traits))
            if (n < 0 || n > 100) fail(`${e.id}: traço inválido`);
          for (const n of Object.values(x.values))
            if (n < -100 || n > 100) fail(`${e.id}: valor inválido`);
          for (const id of x.kin)
            if (!state[id]) fail(`${e.id}: parentesco inválido`);
          for (const id of x.informed)
            if (!ids.has(id)) fail(`${e.id}: conhecimento futuro`);
          for (const id of [x.rival, x.helpFrom, x.helpedBy, x.killer])
            if (id) refs(id, e.id);
          if (x.kin.some((id) => !(state[id] as Person)?.kin?.includes(x.id)))
            fail(`${e.id}: parentesco assimétrico`);
          for (const id of x.personalGoals || []) refs(id, e.id);
          for (const [id, source] of Object.entries(x.acquaintances || {})) {
            refs(id, e.id);
            if (!ids.has(source)) fail(`${e.id}: conhecimento social futuro`);
          }
          for (const [id, bond] of Object.entries(x.bonds || {})) {
            refs(id, e.id);
            if (
              !ids.has(bond.source) ||
              bond.trust < 0 ||
              bond.trust > 100 ||
              bond.interactions < 1
            )
              fail(`${e.id}: vínculo inválido`);
          }
          if (x.goal) refs(x.goal, e.id);
          if (x.memory) refs(x.memory, e.id);
          if (x.death && !ids.has(x.death)) fail(`${e.id}: morte futura`);
          for (const by of Object.values(x.lastBy))
            if (!ids.has(by)) fail(`${e.id}: alteração sem procedência`);
        }
        if (x.kind === "memory") {
          refs(x.owner, e.id);
          refs(x.offender, e.id);
          refs(x.victim, e.id);
          if (!ids.has(x.source)) fail(`${e.id}: memória sem percepção`);
          const source = w.events[Number(x.source.split(":")[1])];
          if (
            source?.type !== "information.received" ||
            !source.participants.some(
              (p) => p.id === x.owner && p.role === "actor",
            )
          )
            fail(`${e.id}: memória onisciente`);
        }
        if (x.kind === "personalGoal") {
          refs(x.owner, e.id);
          refs(x.target, e.id);
          if (!ids.has(x.source) || !ids.has(x.lastEvent))
            fail(`${e.id}: objetivo pessoal sem procedência`);
          const creation = w.events[Number(x.source.split(":")[1])];
          if (creation?.type !== "personalGoal.adopted")
            fail(`${e.id}: origem pessoal inválida`);
          if (x.type === "amizade") {
            const met = (state[x.owner] as Person).acquaintances?.[x.target];
            if (!met || !ids.has(met))
              fail(`${e.id}: amizade sem encontro conhecido`);
            if (
              x.status === "completed" &&
              e.type === "personalGoal.closed" &&
              !e.causes.some(
                (id) =>
                  w.events[Number(id.split(":")[1])]?.type ===
                  "friendship.formed",
              )
            )
              fail(`${e.id}: amizade sem aceitação recíproca`);
          } else if (x.type === "proteger") {
            if (x.aggressor) refs(x.aggressor, e.id);
            const perceived = x.perception
              ? w.events[Number(x.perception.split(":")[1])]
              : undefined;
            if (
              perceived?.type !== "threat.perceived" ||
              perceived.data.observer !== x.owner ||
              perceived.data.threat !== x.threat ||
              (perceived.seq >= e.seq && e.type !== "threat.perceived")
            )
              fail(`${e.id}: proteção sem percepção local`);
            if (
              x.status === "completed" &&
              e.type === "personalGoal.closed" &&
              (!(state[x.owner] as Person).alive ||
                !(state[x.target] as Person).alive ||
                x.interventions < 1)
            )
              fail(`${e.id}: proteção não cumprida`);
          } else fail(`${e.id}: tipo de objetivo desconhecido`);
          if (
            x.closed !== undefined &&
            (x.closed < x.adopted ||
              !["completed", "failed", "abandoned"].includes(x.status || ""))
          )
            fail(`${e.id}: encerramento pessoal inválido`);
        }
        if (x.kind === "goal") {
          refs(x.owner, e.id);
          refs(x.target, e.id);
          refs(x.memory, e.id);
          for (const source of [x.accordIntent, x.accordRejected])
            if (source && !ids.has(source))
              fail(`${e.id}: acordo sem causa válida`);
          if (!ids.has(x.offense) || !ids.has(x.source))
            fail(`${e.id}: objetivo sem ofensa/origem`);
          if (
            x.closed !== undefined &&
            (x.closed < x.adopted || !outcomes.includes(x.outcome!))
          )
            fail(`${e.id}: conclusão inválida`);
          if (x.outcome === "vingança cumprida") {
            const target = state[x.target] as Person;
            if (target.alive || target.killer !== x.owner)
              fail(`${e.id}: vingança sem autoria`);
          }
          if (x.outcome === "alvo morto por outra causa") {
            const target = state[x.target] as Person;
            if (target.alive || target.killer === x.owner)
              fail(`${e.id}: outra causa inválida`);
          }
        }
      }
    }
    if (JSON.stringify(state) !== JSON.stringify(w.entities))
      fail("Replay diverge do estado");
    for (const g of goals(w))
      if (w.complete && g.closed === undefined)
        fail("Objetivo não encerrado no horizonte");
    for (const pg of Object.values(w.entities).filter(
      (e): e is PersonalGoal => e.kind === "personalGoal",
    ))
      if (w.complete && pg.closed === undefined)
        fail("Objetivo pessoal não encerrado no horizonte");
    const periods = new Set<string>();
    for (const e of w.events.filter((e) => e.type === "activity.period")) {
      const key = `${e.month}:${e.decision?.actor}`;
      if (periods.has(key)) fail("Rotina duplicada no mês");
      periods.add(key);
    }
  } catch (error) {
    fail(`Estrutura inválida: ${(error as Error).message}`);
  }
  return errors;
}
// v2-specific entry point; v1 worlds must still use the legacy validator.
export { validateSlice as validateWorld };
