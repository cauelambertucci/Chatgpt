import type {
  Action,
  Candidate,
  Decision,
  Effect,
  Entity,
  Goal,
  Memory,
  Person,
  Reaction,
  Scenario,
  SliceEvent,
  SliceWorld,
  Outcome,
  PersonalGoal,
} from "./types";
import { memoryWeight, noise, rules, sample } from "./rules";
import { presentAt } from "./scenario";
// All persisted state is canonical JSON: no undefined properties or negative zero.
const clone = <T>(x: T): T => JSON.parse(JSON.stringify(x));
function freeze<T>(x: T): T {
  if (x && typeof x === "object" && !Object.isFrozen(x)) {
    Object.freeze(x);
    for (const child of Object.values(x)) freeze(child);
  }
  return x;
}
export function applyEvent(entities: Record<string, Entity>, e: SliceEvent) {
  for (const effect of e.effects) {
    const id = effect.entity.id;
    if (effect.op === "create" && entities[id])
      throw Error(`Duplicate entity ${id}`);
    if (effect.op === "replace" && !entities[id])
      throw Error(`Unknown entity ${id}`);
    entities[id] = clone(effect.entity);
  }
}
export function replay(events: readonly SliceEvent[]): Record<string, Entity> {
  const entities: Record<string, Entity> = {};
  for (const e of events) applyEvent(entities, e);
  return entities;
}
export const people = (w: SliceWorld) =>
  Object.values(w.entities)
    .filter((e): e is Person => e.kind === "person")
    .sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
export const goals = (w: SliceWorld) =>
  Object.values(w.entities).filter((e): e is Goal => e.kind === "goal");
export const getPerson = (w: SliceWorld, id: string) => {
  const p = w.entities[id];
  if (!p || p.kind !== "person") throw Error(`Not a person: ${id}`);
  return p;
};
export const getGoal = (w: SliceWorld, p: Person) =>
  p.goal ? (w.entities[p.goal] as Goal) : undefined;
export function effectiveMemory(w: SliceWorld, p: Person, month: number) {
  const m = p.memory ? (w.entities[p.memory] as Memory) : undefined;
  return m ? memoryWeight(m.weight, m.rancor, month - m.at) : 0;
}
function changed(p: Person, patch: Partial<Person>, id: string): Person {
  return {
    ...clone(p),
    ...patch,
    lastBy: {
      ...p.lastBy,
      ...Object.fromEntries(Object.keys(patch).map((k) => [k, id])),
    },
  };
}
const gReason = (g: PersonalGoal, id: string) =>
  g.owner === id ? "O responsável morreu." : "A pessoa-alvo morreu.";
export class SliceSimulation {
  private state: SliceWorld;
  get world(): SliceWorld {
    return freeze(clone(this.state));
  }
  private month = 0;
  private queue: Reaction[] = [];
  private delivered = new Set<string>();
  private reactedThisMonth = new Set<string>();
  constructor(scenario: Scenario, restored?: SliceWorld) {
    if (restored) {
      const expected = restored.scenario.personalObjectives
        ? "agents-slice-1b"
        : "agents-slice-1a";
      if (!restored.complete && restored.engine !== expected)
        throw Error(
          "Versão incompatível para continuar; histórico anterior disponível somente para leitura.",
        );
      this.state = clone(restored);
      this.state.events = this.state.events.map(freeze);
      this.month = this.state.nextMonth;
      return;
    }
    if (scenario.months < 1 || scenario.months > 240)
      throw Error("Horizon must be 1–240 months");
    this.state = {
      version: 2,
      engine: scenario.personalObjectives
        ? "agents-slice-1b"
        : "agents-slice-1a",
      scenario: clone(scenario),
      events: [],
      entities: {},
      nextMonth: 0,
      complete: false,
    };
    this.emit(
      "world.created",
      [],
      [],
      [
        {
          op: "create",
          entity: { id: "place:void", kind: "place", name: "O lugar sem mapa" },
        },
      ],
      {
        seed: scenario.seed,
        mode: scenario.mode,
        calendar: "360 days, monthly periods",
        schema: 2,
      },
    );
    // Bootstrap related people atomically: no forward kin/rival references.
    const initial = [...scenario.people]
      .sort((a, b) => (a.id < b.id ? -1 : 1))
      .map((input) => {
        const p = clone(input);
        p.present = presentAt(scenario, p.id, 0);
        p.lastBy = Object.fromEntries(
          Object.keys(p).map((k) => [k, this.nextId()]),
        );
        return p;
      });
    this.emit(
      "people.created",
      initial.map((p) => ({ id: p.id, role: "reference" })),
      ["event:0"],
      initial.map((entity) => ({ op: "create", entity })),
      {
        origin: "configured adults",
        description: "Parentesco e rivalidades iniciais criados atomicamente.",
      },
    );
  }

  private nextId() {
    return `event:${this.state.events.length}`;
  }
  private emit(
    type: string,
    participants: SliceEvent["participants"],
    causes: string[],
    effects: Effect[] = [],
    data: Record<string, unknown> = {},
    decision?: Decision,
  ): SliceEvent {
    if (this.state.events.length >= rules.maxEvents)
      throw Error("budget_exceeded: event safety limit");
    const e: SliceEvent = freeze({
      id: this.nextId(),
      seq: this.state.events.length,
      ano: Math.floor(this.month / 12),
      dia: (this.month % 12) * 30,
      month: this.month,
      type,
      participants: clone(participants),
      location: "place:void",
      causes: [...new Set(causes)].sort(
        (a, b) => Number(a.split(":")[1]) - Number(b.split(":")[1]),
      ),
      effects: clone(effects),
      data: clone(data),
      ...(decision ? { decision: clone(decision) } : {}),
    });
    if (type !== "world.created" && !e.causes.length)
      throw Error("Missing cause");
    for (const cause of e.causes)
      if (this.state.events[Number(cause.split(":")[1])]?.id !== cause)
        throw Error(`Future/unknown cause ${cause}`);
    applyEvent(this.state.entities, e);
    this.state.events.push(e);
    this.dispatch(e);
    return e;
  }
  private dispatch(e: SliceEvent) {
    if (e.type === "threat.announced")
      for (const p of people(this.state).filter(
        (p) =>
          p.alive &&
          p.present &&
          p.id !== e.data.aggressor &&
          p.id !== e.data.target,
      ))
        this.enqueue({ kind: "threat", source: e.id, recipient: p.id });
    if (e.type === "person.died") {
      for (const p of people(this.state).filter((p) => p.alive && p.present))
        this.enqueue({ kind: "perceive", source: e.id, recipient: p.id });
      for (const g of goals(this.state).filter(
        (g) =>
          g.closed === undefined &&
          (g.target === e.data.victim || g.owner === e.data.victim),
      ))
        this.enqueue({ kind: "settleDeath", source: e.id, recipient: g.owner });
    }
    if (e.type === "information.shared")
      this.enqueue({
        kind: "hear",
        source: e.id,
        recipient: String(e.data.recipient),
        sender: String(e.data.sender),
      });
    if (e.type === "help.requested")
      this.enqueue({
        kind: "help",
        source: e.id,
        recipient: String(e.data.recipient),
        sender: String(e.data.sender),
      });
  }
  private enqueue(reaction: Reaction) {
    const key = `${reaction.kind}|${reaction.source}|${reaction.recipient}|${reaction.sender || ""}`;
    if (this.delivered.has(key)) return;
    this.delivered.add(key);
    this.queue.push(reaction);
  }
  private drain() {
    let count = 0;
    while (this.queue.length) {
      if (++count > 2000) throw Error("reaction_cycle");
      const r = this.queue.shift()!,
        p = getPerson(this.state, r.recipient);
      if (!p.alive) continue;
      const e = this.state.events[Number(r.source.split(":")[1])];
      if (r.kind === "perceive") this.learn(p, e, e.id);
      if (r.kind === "hear") {
        const offense =
          this.state.events[Number(String(e.data.offense).split(":")[1])];
        if (offense?.type === "person.died") this.learn(p, offense, e.id);
      }
      if (r.kind === "threat") this.perceiveThreat(p, e);
      if (r.kind === "help" && r.sender) {
        const sender = getPerson(this.state, r.sender);
        if (!sender.alive || !sender.present || !p.present || sender.helpedBy)
          continue;
        const willingness =
          p.values.familia +
          p.values.paz +
          p.traits.disciplina -
          p.traits.rancor;
        const id = this.nextId();
        const accepted = p.canHelp && willingness >= 70;
        this.emit(
          "help.responded",
          [
            { id: p.id, role: "actor" },
            { id: sender.id, role: "beneficiary" },
          ],
          [e.id, p.lastBy.values, p.lastBy.canHelp].filter(Boolean),
          accepted
            ? [
                {
                  op: "replace",
                  entity: changed(sender, { helpedBy: p.id }, id),
                },
              ]
            : [],
          { accepted, willingness, request: e.id },
        );
      }
      if (r.kind === "settleDeath") {
        const g = getGoal(this.state, p);
        if (g?.closed !== undefined || !g) continue;
        if (g.owner === e.data.victim)
          this.closeGoal(
            g,
            "objetivo frustrado",
            [e.id],
            "O agente morreu antes de concluir seu objetivo.",
          );
        else if (e.data.killer === g.owner)
          this.closeGoal(
            g,
            "vingança cumprida",
            [e.id],
            "O agente causou a morte do ofensor que buscava.",
          );
        else if (p.informed.includes(e.id))
          this.closeGoal(
            g,
            "alvo morto por outra causa",
            [e.id],
            "A morte do alvo foi atribuída a outro agente.",
          );
      }
    }
  }
  private learn(person: Person, death: SliceEvent, source: string) {
    let p = getPerson(this.state, person.id);
    if (
      this.state.scenario.blockedInformation.includes(p.id) ||
      p.informed.includes(death.id)
    )
      return;
    const id = this.nextId();
    this.emit(
      "information.received",
      [
        { id: p.id, role: "actor" },
        { id: String(death.data.victim), role: "reference" },
      ],
      [source, p.lastBy.present].filter(Boolean),
      [
        {
          op: "replace",
          entity: changed(p, { informed: [...p.informed, death.id] }, id),
        },
      ],
      {
        offense: death.id,
        channel: source === death.id ? "testemunho" : "relato",
        source,
      },
    );
    p = getPerson(this.state, p.id);
    const existing = getGoal(this.state, p);
    if (
      existing &&
      existing.closed === undefined &&
      existing.target === death.data.victim
    ) {
      this.closeGoal(
        existing,
        death.data.killer === p.id
          ? "vingança cumprida"
          : "alvo morto por outra causa",
        [id, death.id],
        "A notícia confirmou a morte do alvo.",
      );
      return;
    }
    if (
      !p.kin.includes(String(death.data.victim)) ||
      !death.data.killer ||
      death.data.killer === p.id ||
      p.goal
    )
      return;
    const memory: Memory = {
      id: `memory:${p.id}`,
      kind: "memory",
      owner: p.id,
      victim: String(death.data.victim),
      offender: String(death.data.killer),
      source: id,
      at: this.month,
      weight: 850,
      offenderSkillEstimate: Number(death.data.killerSkill),
      rancor: p.traits.rancor,
    };
    const mid = this.nextId();
    this.emit(
      "memory.formed",
      [
        { id: p.id, role: "actor" },
        { id: memory.victim, role: "reference" },
      ],
      [id, p.lastBy.traits, p.lastBy.kin].filter(Boolean),
      [
        { op: "create", entity: memory },
        { op: "replace", entity: changed(p, { memory: memory.id }, mid) },
      ],
      { emotion: "luto", offense: death.id, weight: memory.weight },
    );
    p = getPerson(this.state, p.id);
    const desire =
      p.values.vinganca * 5 +
      p.values.familia * 2 +
      p.traits.rancor * 2 -
      p.values.paz * 5;
    const goal: Goal = {
      id: `goal:${p.id}`,
      kind: "goal",
      owner: p.id,
      target: memory.offender,
      victim: memory.victim,
      offense: death.id,
      memory: memory.id,
      adopted: this.month,
      source: this.nextId(),
    };
    const gid = this.nextId();
    this.emit(
      "goal.adopted",
      [
        { id: p.id, role: "actor" },
        { id: goal.target, role: "reference" },
      ],
      [mid, p.lastBy.values].filter(Boolean),
      [
        { op: "create", entity: goal },
        { op: "replace", entity: changed(p, { goal: goal.id }, gid) },
      ],
      { desire, reason: "Avaliar resposta à morte conhecida de um familiar." },
    );
    // Assess response through actions on the next turn, including seeking agreement.
    // Low revenge desire no longer closes the objective before alternatives can be compared.
  }
  private closeGoal(
    goal: Goal,
    outcome: Outcome,
    causes: string[],
    reason: string,
  ) {
    const current = this.state.entities[goal.id] as Goal;
    if (current.closed !== undefined) return;
    this.emit(
      "goal.closed",
      [
        {
          id: goal.owner,
          role: getPerson(this.state, goal.owner).alive ? "actor" : "reference",
        },
        { id: goal.target, role: "reference" },
      ],
      [goal.source, ...causes],
      [{ op: "replace", entity: { ...current, closed: this.month, outcome } }],
      { goal: goal.id, outcome, reason },
    );
  }
  private offerAgreement(goal: Goal): boolean {
    const owner = getPerson(this.state, goal.owner),
      target = getPerson(this.state, goal.target);
    if (
      !owner.alive ||
      !owner.present ||
      !target.alive ||
      !target.present ||
      !goal.accordIntent ||
      goal.accordRejected
    )
      return false;
    const offer = this.emit(
      "agreement.offered",
      [
        { id: owner.id, role: "actor" },
        { id: target.id, role: "target" },
      ],
      [goal.accordIntent, owner.lastBy.present, target.lastBy.present],
      [],
      { goal: goal.id },
    );
    const willingness =
      target.values.paz * 5 +
      target.traits.cautela * 2 +
      target.remorse * 2 -
      target.traits.rancor * 2 -
      target.values.vinganca * 3;
    const accepted = willingness >= 300;
    const reply = this.emit(
      "agreement.responded",
      [
        { id: target.id, role: "actor" },
        { id: owner.id, role: "target" },
      ],
      [
        offer.id,
        target.lastBy.values,
        target.lastBy.traits,
        target.lastBy.remorse,
      ].filter(Boolean),
      accepted
        ? []
        : [
            {
              op: "replace",
              entity: { ...goal, accordRejected: this.nextId() },
            },
          ],
      { goal: goal.id, accepted, willingness },
    );
    if (accepted) {
      const agreed = this.emit(
        "reconciliation.agreed",
        [
          { id: owner.id, role: "actor" },
          { id: target.id, role: "target" },
        ],
        [reply.id, goal.accordIntent],
        [],
        { goal: goal.id, accepted: true, reply: reply.id },
      );
      this.closeGoal(
        goal,
        "reconciliação",
        [agreed.id],
        "Acordo aceito pelos dois agentes após contato efetivo.",
      );
    }
    return true;
  }
  private allPersonalGoals(): PersonalGoal[] {
    return Object.values(this.state.entities).filter(
      (x): x is PersonalGoal => x.kind === "personalGoal",
    );
  }
  private personalGoals(p: Person) {
    return (p.personalGoals || []).map(
      (id) => this.state.entities[id] as PersonalGoal,
    );
  }
  private adoptPersonalGoal(
    p: Person,
    target: Person,
    type: PersonalGoal["type"],
    causes: string[],
    details: Partial<PersonalGoal> = {},
  ): PersonalGoal {
    const id = `personal:${type}:${p.id}:${target.id}`,
      eid = this.nextId();
    const g: PersonalGoal = {
      id,
      kind: "personalGoal",
      type,
      owner: p.id,
      target: target.id,
      source: eid,
      lastEvent: eid,
      adopted: this.month,
      interventions: 0,
      rejections: 0,
      ...details,
    };
    this.emit(
      "personalGoal.adopted",
      [
        { id: p.id, role: "actor" },
        { id: target.id, role: "reference" },
      ],
      causes,
      [
        { op: "create", entity: g },
        {
          op: "replace",
          entity: changed(
            p,
            { personalGoals: [...(p.personalGoals || []), id] },
            eid,
          ),
        },
      ],
      {
        goal: id,
        type,
        reason:
          type === "amizade"
            ? "Desejo de construir amizade com pessoa encontrada."
            : "Compromisso de proteger após ameaça percebida.",
      },
    );
    return g;
  }
  private finishPersonalGoal(
    g: PersonalGoal,
    status: PersonalGoal["status"],
    causes: string[],
    reason: string,
  ) {
    const current = this.state.entities[g.id] as PersonalGoal;
    if (current.closed !== undefined) return;
    this.emit(
      "personalGoal.closed",
      [
        {
          id: g.owner,
          role: getPerson(this.state, g.owner).alive ? "actor" : "reference",
        },
        { id: g.target, role: "reference" },
      ],
      [current.source, current.lastEvent, ...causes],
      [
        {
          op: "replace",
          entity: {
            ...current,
            closed: this.month,
            status,
            reason,
            lastEvent: this.nextId(),
          },
        },
      ],
      { goal: g.id, status, reason },
    );
  }
  private prepareFriendship(p: Person) {
    if (
      (p.values.amizade || 0) < 35 ||
      this.personalGoals(p).some((g) => g.type === "amizade")
    )
      return;
    const target = people(this.state)
      .filter(
        (q) =>
          q.id !== p.id &&
          q.alive &&
          q.present &&
          (!this.state.scenario.friendTargets?.[p.id] ||
            q.id === this.state.scenario.friendTargets[p.id]),
      )
      .sort(
        (a, b) =>
          sample(
            this.state.scenario.seed,
            `contact:${p.id}:${a.id}`,
            0,
            1000000,
          ) -
            sample(
              this.state.scenario.seed,
              `contact:${p.id}:${b.id}`,
              0,
              1000000,
            ) || (a.id < b.id ? -1 : 1),
      )[0];
    if (!target) return;
    let source = p.acquaintances?.[target.id];
    if (!source) {
      const eid = this.nextId();
      const met = this.emit(
        "person.met",
        [
          { id: p.id, role: "actor" },
          { id: target.id, role: "target" },
        ],
        [p.lastBy.present, target.lastBy.present],
        [
          {
            op: "replace",
            entity: changed(
              p,
              { acquaintances: { ...p.acquaintances, [target.id]: eid } },
              eid,
            ),
          },
          {
            op: "replace",
            entity: changed(
              target,
              { acquaintances: { ...target.acquaintances, [p.id]: eid } },
              eid,
            ),
          },
        ],
        { first: p.id, second: target.id },
      );
      source = met.id;
    }
    this.adoptPersonalGoal(
      getPerson(this.state, p.id),
      getPerson(this.state, target.id),
      "amizade",
      [source, p.lastBy.values],
    );
  }
  private socialize(
    p: Person,
    target: Person,
    causes: string[],
    decision: Decision,
  ) {
    const goal = this.personalGoals(p).find(
      (g) =>
        g.type === "amizade" &&
        g.closed === undefined &&
        g.target === target.id,
    );
    if (!goal) return;
    const contact = this.emit(
      "social.invited",
      [
        { id: p.id, role: "actor" },
        { id: target.id, role: "target" },
      ],
      causes,
      [],
      { goal: goal.id },
      decision,
    );
    const willingness =
      (target.values.amizade || 0) +
      target.values.paz +
      target.values.familia -
      target.traits.rancor -
      Math.floor(target.traits.cautela / 2);
    const accepted = willingness >= 85,
      eid = this.nextId();
    const response = this.emit(
      "social.responded",
      [
        { id: target.id, role: "actor" },
        { id: p.id, role: "target" },
      ],
      [contact.id, target.lastBy.values, target.lastBy.traits],
      [],
      { accepted, willingness, goal: goal.id },
    );
    if (!accepted) {
      const g = {
        ...goal,
        rejections: goal.rejections + 1,
        lastEvent: this.nextId(),
      };
      this.emit(
        "friendship.rejected",
        [
          { id: p.id, role: "actor" },
          { id: target.id, role: "reference" },
        ],
        [response.id],
        [{ op: "replace", entity: g }],
        { goal: goal.id },
      );
      if (g.rejections >= 3)
        this.finishPersonalGoal(
          g,
          "abandoned",
          [response.id],
          "Três convites recusados; respeitou a recusa.",
        );
      return;
    }
    const a = getPerson(this.state, p.id),
      b = getPerson(this.state, target.id),
      oldA = a.bonds?.[b.id],
      oldB = b.bonds?.[a.id],
      bid = this.nextId();
    const bond = (old: typeof oldA) => ({
      trust: Math.min(100, (old?.trust || 0) + 20),
      interactions: (old?.interactions || 0) + 1,
      source: bid,
    });
    const ba = bond(oldA),
      bb = bond(oldB);
    const interaction = this.emit(
      "relationship.strengthened",
      [
        { id: a.id, role: "actor" },
        { id: b.id, role: "target" },
      ],
      [
        response.id,
        ...[oldA?.source, oldB?.source].filter((x): x is string => !!x),
      ],
      [
        {
          op: "replace",
          entity: changed(a, { bonds: { ...a.bonds, [b.id]: ba } }, bid),
        },
        {
          op: "replace",
          entity: changed(b, { bonds: { ...b.bonds, [a.id]: bb } }, bid),
        },
      ],
      {
        first: a.id,
        second: b.id,
        firstTrust: ba.trust,
        secondTrust: bb.trust,
      },
    );
    if (ba.trust >= 60 && bb.trust >= 60) {
      const formed = this.emit(
        "friendship.formed",
        [
          { id: a.id, role: "actor" },
          { id: b.id, role: "target" },
        ],
        [interaction.id],
        [],
        { first: a.id, second: b.id, goal: goal.id },
      );
      this.finishPersonalGoal(
        goal,
        "completed",
        [formed.id],
        "Amizade recíproca construída por encontros aceitos.",
      );
    }
  }
  private perceiveThreat(p: Person, threat: SliceEvent) {
    if (this.state.scenario.blockedThreatPerception?.includes(p.id)) return;
    const target = getPerson(this.state, String(threat.data.target)),
      attacker = getPerson(this.state, String(threat.data.aggressor));
    const perception = this.emit(
      "threat.perceived",
      [
        { id: p.id, role: "witness" },
        { id: target.id, role: "reference" },
      ],
      [threat.id, p.lastBy.present],
      [],
      { threat: threat.id, observer: p.id },
    );
    const existing = this.personalGoals(p).find(
      (g) => g.type === "proteger" && g.target === target.id,
    );
    if (existing?.closed !== undefined) return;
    if (existing) {
      this.emit(
        "protection.renewed",
        [
          { id: p.id, role: "actor" },
          { id: target.id, role: "reference" },
        ],
        [existing.lastEvent, perception.id],
        [
          {
            op: "replace",
            entity: {
              ...existing,
              threat: threat.id,
              aggressor: attacker.id,
              perception: perception.id,
              threatResolved: false,
              lastEvent: this.nextId(),
            },
          },
        ],
        { goal: existing.id },
      );
      return;
    }
    const related =
      p.kin.includes(target.id) || (p.bonds?.[target.id]?.trust || 0) >= 20;
    if (!related && (p.values.solidariedade || 0) < 60) return;
    this.adoptPersonalGoal(
      p,
      target,
      "proteger",
      [
        perception.id,
        p.lastBy.values,
        ...(p.bonds?.[target.id] ? [p.bonds[target.id].source] : []),
      ],
      {
        threat: threat.id,
        aggressor: attacker.id,
        perception: perception.id,
        threatResolved: false,
      },
    );
  }
  private protect(
    p: Person,
    targetId: string,
    causes: string[],
    decision: Decision,
  ): boolean {
    const g = this.personalGoals(p).find(
      (g) =>
        g.type === "proteger" &&
        g.closed === undefined &&
        g.target === targetId &&
        !g.threatResolved,
    );
    if (!g?.aggressor || !g.threat) return false;
    const attacker = getPerson(this.state, g.aggressor),
      margin = p.skill + p.traits.coragem * 2 - attacker.skill;
    const success = margin >= 0,
      eid = this.nextId();
    this.emit(
      success ? "protection.intervened" : "protection.failed",
      [
        { id: p.id, role: "actor" },
        { id: targetId, role: "beneficiary" },
        { id: attacker.id, role: "target" },
      ],
      [...causes, g.threat, g.perception!, attacker.lastBy.skill],
      [
        {
          op: "replace",
          entity: {
            ...g,
            interventions: g.interventions + (success ? 1 : 0),
            lastEvent: eid,
          },
        },
        ...(success && attacker.rival === targetId
          ? [
              {
                op: "replace" as const,
                entity: changed(
                  attacker,
                  {
                    rival: undefined,
                    hostility: Math.max(0, attacker.hostility - 50),
                  },
                  eid,
                ),
              },
            ]
          : []),
      ],
      {
        goal: g.id,
        threat: g.threat,
        success,
        margin,
        reason: "Intervenção abstrata, sem dano corporal.",
      },
      decision,
    );
    this.reactedThisMonth.add(p.id);
    return success;
  }
  private resolveThreat(threat: string) {
    for (const g of this.allPersonalGoals().filter(
      (g) => g.closed === undefined && g.threat === threat && !g.threatResolved,
    ))
      this.emit(
        "threat.resolved",
        [
          { id: g.owner, role: "reference" },
          { id: g.target, role: "reference" },
        ],
        [g.lastEvent, threat],
        [
          {
            op: "replace",
            entity: { ...g, threatResolved: true, lastEvent: this.nextId() },
          },
        ],
        { goal: g.id, threat },
      );
  }
  private availability() {
    for (const p of people(this.state)) {
      if (!p.alive || p.escaped) continue;
      const present = presentAt(this.state.scenario, p.id, this.month);
      if (p.present !== present) {
        const id = this.nextId();
        this.emit(
          "presence.changed",
          [{ id: p.id, role: "actor" }],
          [p.lastBy.present, "event:0"],
          [{ op: "replace", entity: changed(p, { present }, id) }],
          {
            present,
            reason: "Agenda abstrata de encontros definida na origem.",
          },
        );
      }
    }
  }
  private targetFor(p: Person) {
    const goal = getGoal(this.state, p);
    if (goal && goal.closed === undefined)
      return getPerson(this.state, goal.target);
    if (p.rival) return getPerson(this.state, p.rival);
    return undefined;
  }
  candidates(id: string): Candidate[] {
    const p = getPerson(this.state, id),
      g = getGoal(this.state, p),
      active = !!g && g.closed === undefined,
      target = this.targetFor(p),
      weight = effectiveMemory(this.state, p, this.month);
    const evidence = (...ids: (string | undefined)[]) => [
      ...new Set(ids.filter((x): x is string => !!x)),
    ];
    const baseEvidence = evidence(
      p.lastBy.traits,
      p.lastBy.values,
      p.lastBy.skill,
      p.lastBy.present,
      g?.source,
      g?.accordIntent,
      g?.accordRejected,
      p.memory ? (this.state.entities[p.memory] as Memory).source : undefined,
    );
    const result: Candidate[] = [];
    const add = (
      action: Action,
      factors: Record<string, number>,
      targetId?: string,
      extra: string[] = [],
    ) => {
      const base = Object.values(factors).reduce((a, b) => a + b, 0),
        jitter = noise(this.state.scenario.seed, p.id, this.month, action);
      result.push({
        action,
        base,
        noise: jitter,
        score: base + jitter,
        factors,
        evidence: evidence(...baseEvidence, ...extra),
        ...(targetId ? { target: targetId } : {}),
      });
    };
    add("esperar", {
      repouso: 300,
      cautela: p.traits.cautela * 2,
      compromissoAcordo:
        active && g!.accordIntent && !g!.accordRejected
          ? 250 + p.values.paz * 2
          : 0,
    });
    if (!p.alive || !p.present) return result;
    const rememberedSkill = p.memory
      ? (this.state.entities[p.memory] as Memory).offenderSkillEstimate
      : target
        ? this.state.scenario.people.find((q) => q.id === target.id)!.skill
        : 0;
    // Co-present activity is public in this abstract scenario. Away, only the known estimate is available.
    const perceivedSkill =
      target?.alive && target.present ? target.skill : rememberedSkill;
    const gap = target ? perceivedSkill - p.skill : 0,
      urge = active
        ? p.values.vinganca * 4 +
          p.values.familia +
          p.traits.rancor +
          Math.floor(weight / 4) -
          p.values.paz * 4
        : 0;
    if (p.trainAccess && p.skill < rules.maxSkill)
      add(
        "treinar",
        {
          pratica: active ? 380 : 100,
          disciplina: p.traits.disciplina * 3,
          preparacao: active ? Math.max(0, Math.floor((gap * 14) / 10)) : 0,
          motivo: active ? Math.floor(urge / 3) : 0,
        },
        undefined,
        evidence(p.lastBy.trainAccess, p.lastBy.helpedBy),
      );
    if (
      target?.alive &&
      target.present &&
      (!active || p.informed.includes(g!.offense))
    )
      add(
        "confrontar",
        {
          iniciativa: active ? 800 : 0,
          motivo: active ? urge : p.hostility * 12,
          poder: (p.skill - target.skill) * 4,
          perigo: -Math.max(0, gap) * 8,
          coragem: p.traits.coragem * 3,
          cautela: -p.traits.cautela * 3,
          paz: -p.values.paz * 3,
        },
        target.id,
        evidence(
          target.lastBy.skill,
          target.lastBy.present,
          p.lastBy.rival,
          p.lastBy.hostility,
        ),
      );
    if (active && target) {
      if (!target.present)
        add(
          "observar",
          {
            busca: active ? 400 : 0,
            compromisso: Math.floor(urge / 3),
            paciencia: p.traits.disciplina,
          },
          target.id,
        );
      if (!p.helpFrom) {
        const helper = people(this.state)
          .filter(
            (q) =>
              q.id !== p.id &&
              q.id !== target.id &&
              q.alive &&
              q.present &&
              q.canHelp,
          )
          .sort(
            (a, b) =>
              b.values.familia +
                b.values.paz -
                a.values.familia -
                a.values.paz || (a.id < b.id ? -1 : 1),
          )[0];
        if (helper)
          add(
            "comunicar",
            {
              pedido: 700,
              cautela: p.traits.cautela * 2,
              paz: p.values.paz * 2,
              orgulho: -p.traits.coragem,
            },
            helper.id,
          );
      }
      if (!g!.accordIntent && !g!.accordRejected)
        add(
          "buscar_acordo",
          {
            paz: p.values.paz * 10,
            familia: p.values.familia * 2,
            rancor: -p.traits.rancor * 2,
            vinganca: -p.values.vinganca * 3,
            alternativa: 300,
          },
          target.id,
        );
      add(
        "perdoar",
        {
          paz: p.values.paz * 6,
          desapego: Math.floor((850 - weight) / 2),
          rancor: -p.traits.rancor * 3,
          vinganca: -p.values.vinganca * 4,
          alternativa: 250,
          aguardarResposta: g!.accordIntent && !g!.accordRejected ? -500 : 0,
          apoio: p.helpedBy ? 100 : 0,
        },
        target.id,
      );
    }
    // Witnesses spread only facts they actually know; a recipient must be present and not already know.
    if (!active) {
      for (const offense of p.informed) {
        const death = this.state.events[Number(offense.split(":")[1])];
        const recipient = people(this.state).find(
          (q) => q.alive && q.present && !q.informed.includes(offense),
        );
        if (recipient) {
          add(
            "comunicar",
            { noticia: 900, familia: p.values.familia * 2, paz: p.values.paz },
            recipient.id,
            [offense],
          );
          break;
        }
      }
    }
    if (this.state.scenario.personalObjectives) {
      for (const pg of this.personalGoals(p).filter(
        (g) => g.closed === undefined,
      )) {
        const other = getPerson(this.state, pg.target);
        if (!other.alive || !other.present) continue;
        const sources = [
          pg.source,
          pg.lastEvent,
          p.acquaintances?.[other.id],
          p.bonds?.[other.id]?.source,
        ].filter((x): x is string => !!x);
        if (pg.type === "amizade")
          add(
            "conviver",
            {
              vinculo: (p.values.amizade || 0) * 6,
              familia: p.values.familia * 2,
              objetivo: 300,
              ressentimento: -p.traits.rancor,
            },
            other.id,
            sources,
          );
        if (
          pg.type === "proteger" &&
          pg.threat &&
          !pg.threatResolved &&
          pg.aggressor
        ) {
          const attacker = getPerson(this.state, pg.aggressor);
          if (attacker.alive && attacker.present)
            add(
              "proteger",
              {
                solidariedade: (p.values.solidariedade || 0) * 5,
                coragem: p.traits.coragem * 3,
                vinculo: p.kin.includes(other.id)
                  ? p.values.familia * 4
                  : (p.bonds?.[other.id]?.trust || 0) * 3,
                urgencia: 300,
                risco: -Math.max(0, attacker.skill - p.skill) * 3,
                cautela: -p.traits.cautela * 2,
              },
              other.id,
              [...sources, pg.perception!, attacker.lastBy.skill],
            );
        }
      }
    }
    return result.sort(
      (a, b) => b.score - a.score || (a.action < b.action ? -1 : 1),
    );
  }
  private act(id: string) {
    let p = getPerson(this.state, id);
    if (!p.alive || !p.present || this.reactedThisMonth.has(id)) return;
    if (this.state.scenario.personalObjectives) {
      this.prepareFriendship(p);
      p = getPerson(this.state, id);
    }
    let goal = getGoal(this.state, p);
    if (
      goal &&
      goal.closed === undefined &&
      effectiveMemory(this.state, p, this.month) < rules.minMemory
    ) {
      this.closeGoal(
        goal,
        "desistência",
        [(this.state.entities[goal.memory] as Memory).source],
        "A ofensa perdeu força ao longo dos períodos, conforme o rancor.",
      );
      goal = getGoal(this.state, p);
    }
    if (
      goal &&
      goal.closed === undefined &&
      goal.accordIntent &&
      !goal.accordRejected
    ) {
      if (this.offerAgreement(goal)) return;
    }
    const candidates = this.candidates(id),
      chosen = candidates[0];
    const reason =
      goal && goal.closed === undefined
        ? `${chosen.action} diante da morte conhecida de ${goal.victim}, atribuída a ${goal.target}; risco, valores e capacidade comparados.`
        : chosen.action === "confrontar"
          ? "Confrontar rival conhecido por hostilidade e oportunidade."
          : chosen.action === "comunicar"
            ? "Transmitir uma morte conhecida a alguém ainda sem notícia."
            : "Rotina mensal conforme disciplina, capacidade e cautela.";
    const decision: Decision = {
      actor: id,
      chosen: chosen.action,
      target: chosen.target,
      reason,
      candidates,
    };
    const causes = chosen.evidence.length ? chosen.evidence : ["event:0"];
    if (chosen.action === "conviver") {
      this.socialize(
        p,
        getPerson(this.state, chosen.target!),
        causes,
        decision,
      );
      return;
    }
    if (chosen.action === "proteger") {
      this.protect(p, chosen.target!, causes, decision);
      return;
    }
    if (chosen.action === "confrontar") {
      this.confront(p, getPerson(this.state, chosen.target!), causes, decision);
      return;
    }
    if (chosen.action === "comunicar") {
      const target = getPerson(this.state, chosen.target!),
        g = getGoal(this.state, p);
      const active = g && g.closed === undefined;
      const offense = active
        ? g.offense
        : p.informed.find((o) => !target.informed.includes(o));
      if (!offense) return;
      const eid = this.nextId();
      if (active)
        this.emit(
          "help.requested",
          [
            { id: p.id, role: "actor" },
            { id: target.id, role: "target" },
          ],
          causes,
          [{ op: "replace", entity: changed(p, { helpFrom: target.id }, eid) }],
          { sender: p.id, recipient: target.id, offense, periodMonths: 1 },
          decision,
        );
      this.emit(
        "information.shared",
        [
          { id: p.id, role: "actor" },
          { id: target.id, role: "target" },
        ],
        [...causes, ...(active ? [eid] : []), offense],
        [],
        { sender: p.id, recipient: target.id, offense },
        active ? undefined : decision,
      );
      return;
    }
    if (
      chosen.action === "buscar_acordo" &&
      goal &&
      goal.closed === undefined
    ) {
      const e = this.emit(
        "agreement.sought",
        [
          { id: p.id, role: "actor" },
          { id: goal.target, role: "reference" },
        ],
        causes,
        [{ op: "replace", entity: { ...goal, accordIntent: this.nextId() } }],
        {
          goal: goal.id,
          reason: "Buscar acordo bilateral; ausência não significa recusa.",
        },
        decision,
      );
      this.offerAgreement({ ...goal, accordIntent: e.id });
      return;
    }
    if (chosen.action === "perdoar" && goal && goal.closed === undefined) {
      const e = this.emit(
        "forgiveness.chosen",
        [
          { id: p.id, role: "actor" },
          { id: goal.target, role: "reference" },
        ],
        causes,
        [],
        {
          unilateral: true,
          reason: "Renúncia pessoal, sem depender da aceitação do outro.",
        },
        decision,
      );
      this.closeGoal(
        goal,
        "desistência",
        [e.id],
        "O agente perdoou unilateralmente e encerrou sua vingança.",
      );
      return;
    }
    const gain =
      chosen.action === "treinar"
        ? Math.min(
            rules.maxSkill - p.skill,
            (goal && goal.closed === undefined ? 4 : 1) +
              Math.floor(p.traits.disciplina / 20) +
              (p.helpedBy ? 4 : 0),
          )
        : 0;
    const eid = this.nextId();
    this.emit(
      "activity.period",
      [{ id: p.id, role: "actor" }],
      causes,
      gain
        ? [
            {
              op: "replace",
              entity: changed(p, { skill: p.skill + gain }, eid),
            },
          ]
        : [],
      {
        action: chosen.action,
        periodMonths: 1,
        skillBefore: p.skill,
        gain,
        skillAfter: p.skill + gain,
        memoryWeight: effectiveMemory(this.state, p, this.month),
      },
      decision,
    );
  }
  private confront(
    actor: Person,
    target: Person,
    causes: string[],
    decision: Decision,
  ) {
    if (this.state.scenario.personalObjectives) {
      const threat = this.emit(
        "threat.announced",
        [
          { id: actor.id, role: "actor" },
          { id: target.id, role: "target" },
        ],
        causes,
        [],
        { aggressor: actor.id, target: target.id },
        decision,
      );
      this.drain();
      let interrupted = false;
      for (const protector of people(this.state).filter(
        (p) => p.alive && p.present && p.id !== actor.id && p.id !== target.id,
      )) {
        const pg = this.personalGoals(protector).find(
          (g) =>
            g.type === "proteger" &&
            g.closed === undefined &&
            g.threat === threat.id,
        );
        if (!pg) continue;
        const choices = this.candidates(protector.id),
          choice = choices[0];
        if (choice?.action !== "proteger" || choice.target !== target.id)
          continue;
        const d: Decision = {
          actor: protector.id,
          chosen: "proteger",
          target: target.id,
          candidates: choices,
          reason:
            "Intervir em ameaça que presenciei contra pessoa conhecida ou por solidariedade.",
        };
        if (this.protect(protector, target.id, choice.evidence, d)) {
          interrupted = true;
          break;
        }
      }
      if (interrupted) {
        this.emit(
          "confrontation.prevented",
          [
            { id: actor.id, role: "actor" },
            { id: target.id, role: "target" },
          ],
          [
            threat.id,
            ...Object.values(this.state.entities)
              .filter(
                (x): x is PersonalGoal =>
                  x.kind === "personalGoal" && x.threat === threat.id,
              )
              .map((g) => g.lastEvent),
          ],
          [],
          { threat: threat.id },
        );
        this.resolveThreat(threat.id);
        return;
      }
      causes = [threat.id];
    }
    const jitter = sample(
      this.state.scenario.seed,
      `combat:${actor.id}:${target.id}:${this.month}`,
      -30,
      30,
    );
    const advantage = actor.skill - target.skill + jitter;
    const threat =
      actor.skill -
      target.skill +
      target.traits.cautela * 3 -
      target.traits.coragem * 2;
    const flee = threat > rules.flightMargin && target.traits.cautela > 35;
    const winner = advantage >= 0 ? actor : target,
      loser = advantage >= 0 ? target : actor;
    const lethal = !flee && Math.abs(advantage) >= rules.lethalMargin;
    const resolution = flee ? "fuga" : lethal ? "morte" : "recuo";
    const eid = this.nextId();
    const effects: Effect[] = flee
      ? [
          {
            op: "replace",
            entity: changed(target, { escaped: true, present: false }, eid),
          },
        ]
      : [];
    const e = this.emit(
      "confrontation.resolved",
      [
        { id: actor.id, role: "actor" },
        { id: target.id, role: "target" },
      ],
      [...causes, target.lastBy.traits, target.lastBy.skill].filter(Boolean),
      effects,
      {
        abstract: true,
        defenderResponse: {
          actor: target.id,
          chosen: flee ? "fugir" : "resistir",
          fleeEligible: target.traits.cautela > 35,
          utilities: { fugir: threat - rules.flightMargin, resistir: 0 },
          reason:
            "Ameaça e cautela comparadas à opção de resistir; resposta abstrata, sem corpo.",
        },
        advantage,
        jitter,
        threat,
        result: resolution,
        winner: !flee ? winner.id : null,
        loser: !flee ? loser.id : target.id,
        weapon: null,
        bodyPart: null,
      },
      this.state.scenario.personalObjectives ? undefined : decision,
    );
    if (this.state.scenario.personalObjectives) {
      const threat = [...this.state.events]
        .reverse()
        .find(
          (x) =>
            x.type === "threat.announced" &&
            x.data.aggressor === actor.id &&
            x.data.target === target.id,
        );
      if (threat) this.resolveThreat(threat.id);
    }
    if (flee) {
      for (const g of goals(this.state).filter(
        (g) =>
          g.closed === undefined &&
          g.target === target.id &&
          g.owner === actor.id,
      ))
        this.closeGoal(
          g,
          "fuga",
          [e.id],
          "O alvo escolheu escapar diante da ameaça superior; não houve morte.",
        );
      return;
    }
    if (lethal) this.die(loser, winner.id, e.id);
  }
  private die(p: Person, killer: string | undefined, cause: string) {
    const current = getPerson(this.state, p.id);
    if (!current.alive) return;
    const id = this.nextId();
    this.emit(
      "person.died",
      [
        { id: p.id, role: "victim" },
        ...(killer ? [{ id: killer, role: "actor" as const }] : []),
      ],
      [cause, current.lastBy.alive],
      [
        {
          op: "replace",
          entity: changed(current, { alive: false, death: id, killer }, id),
        },
      ],
      {
        victim: p.id,
        killer: killer || null,
        killerSkill: killer ? getPerson(this.state, killer).skill : null,
        cause: "confronto abstrato",
        weapon: null,
        bodyPart: null,
      },
    );
    for (const pg of this.allPersonalGoals().filter(
      (g) => g.closed === undefined && (g.owner === p.id || g.target === p.id),
    ))
      this.finishPersonalGoal(pg, "failed", [id], gReason(pg, p.id));
    if (killer) {
      const k = getPerson(this.state, killer);
      const remorse = Math.floor(
        (k.values.paz + k.values.familia + k.traits.cautela) / 3,
      );
      const rid = this.nextId();
      this.emit(
        "remorse.felt",
        [
          { id: k.id, role: "actor" },
          { id: p.id, role: "reference" },
        ],
        [id, k.lastBy.values],
        [{ op: "replace", entity: changed(k, { remorse }, rid) }],
        { remorse, reason: "Avaliação da própria morte causada." },
      );
    }
  }
  run(untilMonth = this.state.scenario.months): SliceWorld {
    const end = Math.min(untilMonth, this.state.scenario.months);
    for (this.month = this.state.nextMonth; this.month < end; this.month++) {
      this.reactedThisMonth.clear();
      this.availability();
      const s = this.state.scenario;
      if (s.externalDeathMonth === this.month) {
        const p = getPerson(this.state, s.offender);
        if (p.alive) {
          const e = this.emit(
            "external.incident",
            [{ id: p.id, role: "reference" }],
            ["event:0"],
            [],
            {
              fixture: true,
              reason: "Intervenção de teste: outra causa, não geração livre.",
            },
          );
          this.die(p, undefined, e.id);
        }
      }
      this.drain();
      for (const p of people(this.state)) {
        this.act(p.id);
        this.drain();
      }
      this.state.nextMonth = this.month + 1;
    }
    if (
      this.state.nextMonth === this.state.scenario.months &&
      !this.state.complete
    ) {
      this.month = this.state.nextMonth - 1;
      for (const g of goals(this.state).filter((g) => g.closed === undefined))
        this.closeGoal(
          g,
          "objetivo frustrado",
          [g.source],
          "O horizonte terminou sem resolução.",
        );
      for (const pg of this.allPersonalGoals().filter(
        (g) => g.closed === undefined,
      )) {
        const success =
          pg.type === "proteger" &&
          getPerson(this.state, pg.owner).alive &&
          getPerson(this.state, pg.target).alive &&
          pg.interventions > 0;
        this.finishPersonalGoal(
          pg,
          success ? "completed" : "failed",
          [pg.lastEvent],
          success
            ? "Pessoa protegida viva no horizonte e intervenção efetiva registrada."
            : "Horizonte encerrado sem satisfazer o objetivo.",
        );
      }
      this.state.complete = true;
    }
    return clone(this.state);
  }
}
export function simulateSlice(scenario: Scenario) {
  return new SliceSimulation(scenario).run();
}
